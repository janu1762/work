from django.apps import AppConfig


class WebpagesConfig(AppConfig):
    name = 'webpages'

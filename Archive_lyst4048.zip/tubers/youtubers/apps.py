from django.apps import AppConfig


class YoutubersConfig(AppConfig):
    name = 'youtubers'

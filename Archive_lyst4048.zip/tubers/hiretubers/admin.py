from django.contrib import admin
from .models import Hiretuber
# Register your models here.

admin.site.register(Hiretuber)

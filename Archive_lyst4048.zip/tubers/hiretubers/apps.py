from django.apps import AppConfig


class HiretubersConfig(AppConfig):
    name = 'hiretubers'
